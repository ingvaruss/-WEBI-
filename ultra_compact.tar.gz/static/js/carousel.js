// Плавная карусель с правильным поведением карточек
class SmoothCarousel {
    constructor() {
        this.carousel = document.getElementById('skillsCarousel');
        this.cards = Array.from(this.carousel.querySelectorAll('.skill-card'));
        this.totalCards = this.cards.length;
        this.currentIndex = 0;
        this.targetRotation = 0;
        this.isDragging = false;
        this.startX = 0;
        this.currentX = 0;
        this.velocity = 0;
        this.lastTimestamp = 0;
        this.animationId = null;
        
        this.init();
    }
    
    init() {
        this.arrangeCards();
        this.bindEvents();
        this.animate();
        this.updateActiveCard();
    }
    
    // Располагаем карточки по кругу
    arrangeCards() {
        const radius = 400;
        const angle = 360 / this.totalCards;
        
        this.cards.forEach((card, index) => {
            const rotateY = angle * index;
            const translateZ = radius;
            
            card.style.transform = `rotateY(${rotateY}deg) translateZ(${translateZ}px)`;
            card.dataset.index = index;
        });
    }
    
    // Основной цикл анимации
    animate(timestamp) {
        if (!this.lastTimestamp) this.lastTimestamp = timestamp;
        const delta = Math.min(timestamp - this.lastTimestamp, 16);
        this.lastTimestamp = timestamp;
        
        // Плавное следование к целевой позиции
        if (!this.isDragging) {
            const currentRotation = this.getCurrentRotation();
            const diff = this.targetRotation - currentRotation;
            
            if (Math.abs(diff) > 0.1) {
                const newRotation = currentRotation + diff * 0.1;
                this.carousel.style.transform = `rotateX(-10deg) rotateY(${newRotation}deg)`;
                this.updateActiveCard();
            }
        }
        
        this.animationId = requestAnimationFrame((t) => this.animate(t));
    }
    
    // Получаем текущее вращение
    getCurrentRotation() {
        const transform = this.carousel.style.transform;
        const match = transform.match(/rotateY\(([-]?\d+)deg\)/);
        return match ? parseFloat(match[1]) : 0;
    }
    
    // Обновляем активную карточку
    updateActiveCard() {
        const angle = 360 / this.totalCards;
        const currentRotation = this.getCurrentRotation();
        let activeIndex = Math.round((currentRotation % 360) / angle);
        activeIndex = (activeIndex + this.totalCards) % this.totalCards;
        
        this.cards.forEach((card, index) => {
            card.classList.remove('active', 'left', 'right', 'hidden', 'flipped');
            
            const diff = (index - activeIndex + this.totalCards) % this.totalCards;
            
            if (diff === 0) {
                card.classList.add('active');
            } else if (diff === 1 || diff === this.totalCards - 1) {
                card.classList.add(diff === 1 ? 'right' : 'left');
            } else if (diff <= 2 || diff >= this.totalCards - 2) {
                // visible cards
            } else {
                card.classList.add('hidden');
            }
        });
        
        this.currentIndex = activeIndex;
    }
    
    // Вращаем карусель
    rotate(direction) {
        const angle = 360 / this.totalCards;
        this.targetRotation += angle * direction;
    }
    
    // Flip карточки
    flipCard(card) {
        // Сбрасываем flip у всех карточек
        this.cards.forEach(c => c.classList.remove('flipped'));
        // Переворачиваем выбранную
        card.classList.add('flipped');
    }
    
    // Обработчики событий
    bindEvents() {
        // Перетаскивание мышью
        this.carousel.addEventListener('mousedown', (e) => {
            this.startDrag(e.clientX);
            e.preventDefault();
        });
        
        document.addEventListener('mousemove', (e) => {
            this.drag(e.clientX);
        });
        
        document.addEventListener('mouseup', () => {
            this.endDrag();
        });
        
        // Touch события
        this.carousel.addEventListener('touchstart', (e) => {
            this.startDrag(e.touches[0].clientX);
            e.preventDefault();
        });
        
        document.addEventListener('touchmove', (e) => {
            this.drag(e.touches[0].clientX);
        });
        
        document.addEventListener('touchend', () => {
            this.endDrag();
        });
        
        // Клик по карточкам
        this.cards.forEach((card) => {
            card.addEventListener('click', (e) => {
                if (this.isDragging) return; // Игнорируем клик при перетаскивании
                
                const index = parseInt(card.dataset.index);
                if (index === this.currentIndex) {
                    // Если кликнули на активную карточку - flip
                    this.flipCard(card);
                } else {
                    // Если кликнули на другую карточку - вращаем к ней
                    const angle = 360 / this.totalCards;
                    this.targetRotation = -angle * index;
                }
                e.stopPropagation();
            });
        });
        
        // Сброс flip при клике вне карточек
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.skill-card')) {
                this.cards.forEach(card => card.classList.remove('flipped'));
            }
        });
        
        // Клавиатура
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft') this.rotate(-1);
            if (e.key === 'ArrowRight') this.rotate(1);
            if (e.key === 'Escape') {
                this.cards.forEach(card => card.classList.remove('flipped'));
            }
        });
    }
    
    startDrag(clientX) {
        this.isDragging = true;
        this.startX = clientX;
        this.currentX = clientX;
        this.velocity = 0;
        this.lastX = clientX;
        this.lastTimestamp = performance.now();
        this.carousel.style.cursor = 'grabbing';
        this.carousel.style.transition = 'none';
    }
    
    drag(clientX) {
        if (!this.isDragging) return;
        
        const timestamp = performance.now();
        const deltaTime = timestamp - this.lastTimestamp;
        
        this.currentX = clientX;
        const deltaX = this.currentX - this.lastX;
        this.lastX = this.currentX;
        
        if (deltaTime > 0) {
            this.velocity = deltaX / deltaTime;
        }
        
        // Вращаем карусель пропорционально движению мыши
        const rotation = this.getCurrentRotation() + (deltaX / window.innerWidth) * 180;
        this.carousel.style.transform = `rotateX(-10deg) rotateY(${rotation}deg)`;
        this.updateActiveCard();
        
        this.lastTimestamp = timestamp;
    }
    
    endDrag() {
        if (!this.isDragging) return;
        
        this.isDragging = false;
        this.carousel.style.cursor = 'grab';
        this.carousel.style.transition = 'transform 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
        
        // Применяем инерцию
        this.applyInertia();
    }
    
    applyInertia() {
        const inertia = () => {
            if (Math.abs(this.velocity) > 0.1) {
                const rotation = this.getCurrentRotation() + this.velocity * 2;
                this.carousel.style.transform = `rotateX(-10deg) rotateY(${rotation}deg)`;
                this.velocity *= 0.95; // Замедление
                this.updateActiveCard();
                requestAnimationFrame(inertia);
            } else {
                // Снимгаем к ближайшей карточке
                const angle = 360 / this.totalCards;
                const currentRotation = this.getCurrentRotation();
                let targetIndex = Math.round((currentRotation % 360) / angle);
                targetIndex = (targetIndex + this.totalCards) % this.totalCards;
                this.targetRotation = -angle * targetIndex;
            }
        };
        
        inertia();
    }
}

// Инициализация
document.addEventListener('DOMContentLoaded', () => {
    new SmoothCarousel();
});
