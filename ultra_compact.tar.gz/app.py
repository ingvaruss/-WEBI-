from flask import Flask, render_template

app = Flask(__name__)
app.secret_key = 'dev-key-123'

# Обновленные данные с правильным именем
PORTFOLIO_DATA = {
    "name": "Петров Руслан",  # 👈 ИСПРАВЛЕНО
    "title": "Python Разработчик",
    "about": "Full-stack разработчик с опытом создания веб-приложений на Python и Flask. Специализируюсь на создании современных и функциональных решений.",
    "skills": ["Python", "Flask", "HTML/CSS", "JavaScript", "Git", "SQL", "Django"],
    "projects": [
        {
            "name": "Интернет-магазин",
            "description": "Полнофункциональный интернет-магазин с корзиной и системой оплаты",
            "technologies": ["Python", "Flask", "PostgreSQL", "JavaScript", "Stripe API"],
            "github_url": "#",
            "demo_url": "#"
        },
        {
            "name": "Аналитический дашборд", 
            "description": "Дашборд для визуализации данных с интерактивными графиками",
            "technologies": ["Python", "Dash", "Plotly", "Pandas", "SQL"],
            "github_url": "#",
            "demo_url": "#"
        },
        {
            "name": "Сайт-портфолио",
            "description": "Персональный сайт-портфолио с 3D эффектами",
            "technologies": ["Python", "Flask", "HTML/CSS", "JavaScript"],
            "github_url": "#",
            "demo_url": "http://PRusya.pythonanywhere.com"
        }
    ],
    "contact": {
        "email": "ruslan.petrov@example.com",  # 👈 Замените на реальный email
        "phone": "+7 (999) 123-45-67",
        "github": "https://github.com/yourusername",  # 👈 Замените на ваш GitHub
        "telegram": "https://t.me/yourusername"  # 👈 Замените на ваш Telegram
    }
}

@app.route('/')
def index():
    return render_template('index.html', data=PORTFOLIO_DATA)

@app.route('/about')
def about():
    return render_template('about.html', data=PORTFOLIO_DATA)

@app.route('/projects')
def projects():
    return render_template('projects.html', data=PORTFOLIO_DATA)

@app.route('/contact')
def contact():
    return render_template('contact.html', data=PORTFOLIO_DATA)

@app.route('/health')
def health():
    return "OK"

if __name__ == '__main__':
    app.run(debug=True)
