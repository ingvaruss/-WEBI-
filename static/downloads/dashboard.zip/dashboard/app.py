"""
📊 ИНТЕРАКТИВНЫЙ ДАШБОРД ДЛЯ ВИЗУАЛИЗАЦИИ ДАННЫХ
Автор: Петров Руслан
"""
import dash
from dash import dcc, html, Input, Output, callback
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# Инициализация приложения Dash
app = dash.Dash(__name__, title='Аналитический дашборд')
server = app.server

# Генерация демо-данных
def generate_sample_data():
    """Генерация демонстрационных данных"""
    np.random.seed(42)
    
    # Данные о продажах
    dates = pd.date_range(start='2024-01-01', end='2024-03-31', freq='D')
    categories = ['Электроника', 'Одежда', 'Книги', 'Спорт', 'Красота']
    regions = ['Москва', 'СПб', 'Новосибирск', 'Екатеринбург', 'Казань']
    
    data = []
    for date in dates:
        for category in categories:
            for region in regions:
                sales = np.random.poisson(50)
                revenue = sales * np.random.uniform(100, 5000)
                profit = revenue * np.random.uniform(0.1, 0.4)
                data.append({
                    'date': date,
                    'category': category,
                    'region': region,
                    'sales': sales,
                    'revenue': revenue,
                    'profit': profit
                })
    
    return pd.DataFrame(data)

# Загрузка данных
df = generate_sample_data()

# Цветовая схема
colors = {
    'background': '#1E1E1E',
    'text': '#FFFFFF',
    'card_bg': '#2D2D2D',
    'accent': '#00D4FF',
    'secondary': '#6C63FF'
}

# Макет приложения
app.layout = html.Div([
    # Заголовок и навигация
    html.Div([
        html.H1("📊 Аналитический дашборд", 
                style={'color': colors['text'], 'textAlign': 'center', 'marginBottom': '30px'}),
        
        html.Div([
            html.Button("📈 Продажи", id='btn-sales', n_clicks=0, 
                       style={'margin': '5px', 'background': colors['accent']}),
            html.Button("💰 Финансы", id='btn-finance', n_clicks=0, 
                       style={'margin': '5px', 'background': colors['secondary']}),
            html.Button("🌍 География", id='btn-geo', n_clicks=0, 
                       style={'margin': '5px', 'background': colors['secondary']}),
            html.Button("🔄 Обновить", id='btn-refresh', n_clicks=0, 
                       style={'margin': '5px', 'background': '#27ae60'})
        ], style={'textAlign': 'center', 'marginBottom': '20px'})
    ], style={'backgroundColor': colors['background'], 'padding': '20px'}),
    
    # Фильтры и контролы
    html.Div([
        html.Div([
            html.Label("📅 Диапазон дат:", style={'color': colors['text']}),
            dcc.DatePickerRange(
                id='date-picker',
                start_date=df['date'].min(),
                end_date=df['date'].max(),
                display_format='YYYY-MM-DD'
            )
        ], style={'width': '30%', 'display': 'inline-block', 'margin': '10px'}),
        
        html.Div([
            html.Label("📦 Категории:", style={'color': colors['text']}),
            dcc.Dropdown(
                id='category-filter',
                options=[{'label': cat, 'value': cat} for cat in df['category'].unique()],
                value=df['category'].unique().tolist(),
                multi=True
            )
        ], style={'width': '30%', 'display': 'inline-block', 'margin': '10px'}),
        
        html.Div([
            html.Label("🌍 Регионы:", style={'color': colors['text']}),
            dcc.Dropdown(
                id='region-filter',
                options=[{'label': reg, 'value': reg} for reg in df['region'].unique()],
                value=df['region'].unique().tolist(),
                multi=True
            )
        ], style={'width': '30%', 'display': 'inline-block', 'margin': '10px'})
    ], style={'backgroundColor': colors['card_bg'], 'padding': '15px', 'borderRadius': '10px', 'margin': '10px'}),
    
    # Ключевые метрики
    html.Div([
        html.Div([
            html.H3("💰 Общая выручка", id="total-revenue", 
                   style={'color': colors['accent'], 'textAlign': 'center'}),
            html.P("За выбранный период", style={'color': colors['text'], 'textAlign': 'center'})
        ], style={'width': '24%', 'display': 'inline-block', 'backgroundColor': colors['card_bg'], 
                 'padding': '15px', 'margin': '5px', 'borderRadius': '10px'}),
        
        html.Div([
            html.H3("📦 Продажи", id="total-sales", 
                   style={'color': colors['accent'], 'textAlign': 'center'}),
            html.P("Количество транзакций", style={'color': colors['text'], 'textAlign': 'center'})
        ], style={'width': '24%', 'display': 'inline-block', 'backgroundColor': colors['card_bg'], 
                 'padding': '15px', 'margin': '5px', 'borderRadius': '10px'}),
        
        html.Div([
            html.H3("💵 Прибыль", id="total-profit", 
                   style={'color': colors['accent'], 'textAlign': 'center'}),
            html.P("Чистая прибыль", style={'color': colors['text'], 'textAlign': 'center'})
        ], style={'width': '24%', 'display': 'inline-block', 'backgroundColor': colors['card_bg'], 
                 'padding': '15px', 'margin': '5px', 'borderRadius': '10px'}),
        
        html.Div([
            html.H3("📊 Конверсия", id="conversion-rate", 
                   style={'color': colors['accent'], 'textAlign': 'center'}),
            html.P("Средний чек", style={'color': colors['text'], 'textAlign': 'center'})
        ], style={'width': '24%', 'display': 'inline-block', 'backgroundColor': colors['card_bg'], 
                 'padding': '15px', 'margin': '5px', 'borderRadius': '10px'})
    ], style={'textAlign': 'center', 'margin': '20px 0'}),
    
    # Графики
    html.Div([
        # Первая строка графиков
        html.Div([
            dcc.Graph(id='sales-trend', style={'width': '49%', 'display': 'inline-block'}),
            dcc.Graph(id='category-pie', style={'width': '49%', 'display': 'inline-block'})
        ]),
        
        # Вторая строка графиков
        html.Div([
            dcc.Graph(id='regional-map', style={'width': '49%', 'display': 'inline-block'}),
            dcc.Graph(id='profit-margin', style={'width': '49%', 'display': 'inline-block'})
        ]),
        
        # Третья строка графиков
        html.Div([
            dcc.Graph(id='category-comparison', style={'width': '100%'})
        ])
    ]),
    
    # Автообновление
    dcc.Interval(
        id='interval-component',
        interval=60*1000,  # 1 минута
        n_intervals=0
    ),
    
    # Футер
    html.Div([
        html.Hr(),
        html.P("📊 Дашборд разработан Петровым Русланом | Python + Dash + Plotly", 
              style={'color': colors['text'], 'textAlign': 'center', 'fontSize': '12px'})
    ], style={'marginTop': '30px'})
], style={'backgroundColor': colors['background'], 'padding': '10px'})

# Callback для обновления данных
@app.callback(
    [Output('total-revenue', 'children'),
     Output('total-sales', 'children'),
     Output('total-profit', 'children'),
     Output('conversion-rate', 'children')],
    [Input('date-picker', 'start_date'),
     Input('date-picker', 'end_date'),
     Input('category-filter', 'value'),
     Input('region-filter', 'value'),
     Input('interval-component', 'n_intervals')]
)
def update_metrics(start_date, end_date, categories, regions, n):
    filtered_df = df[
        (df['date'] >= start_date) & 
        (df['date'] <= end_date) &
        (df['category'].isin(categories)) &
        (df['region'].isin(regions))
    ]
    
    total_revenue = f"₽{filtered_df['revenue'].sum():,.0f}"
    total_sales = f"{filtered_df['sales'].sum():,}"
    total_profit = f"₽{filtered_df['profit'].sum():,.0f}"
    avg_check = f"₽{filtered_df['revenue'].sum() / filtered_df['sales'].sum():.0f}" if filtered_df['sales'].sum() > 0 else "₽0"
    
    return total_revenue, total_sales, total_profit, avg_check

# Callback для графиков
@app.callback(
    [Output('sales-trend', 'figure'),
     Output('category-pie', 'figure'),
     Output('regional-map', 'figure'),
     Output('profit-margin', 'figure'),
     Output('category-comparison', 'figure')],
    [Input('date-picker', 'start_date'),
     Input('date-picker', 'end_date'),
     Input('category-filter', 'value'),
     Input('region-filter', 'value')]
)
def update_charts(start_date, end_date, categories, regions):
    filtered_df = df[
        (df['date'] >= start_date) & 
        (df['date'] <= end_date) &
        (df['category'].isin(categories)) &
        (df['region'].isin(regions))
    ]
    
    # 1. Тренд продаж по времени
    daily_sales = filtered_df.groupby('date').agg({'sales': 'sum', 'revenue': 'sum'}).reset_index()
    fig_trend = px.line(daily_sales, x='date', y='sales', 
                       title='📈 Динамика продаж по дням',
                       color_discrete_sequence=[colors['accent']])
    fig_trend.update_layout(plot_bgcolor=colors['card_bg'], paper_bgcolor=colors['background'],
                          font_color=colors['text'])
    
    # 2. Круговая диаграмма по категориям
    category_data = filtered_df.groupby('category').agg({'revenue': 'sum'}).reset_index()
    fig_pie = px.pie(category_data, values='revenue', names='category',
                    title='🥧 Распределение выручки по категориям',
                    color_discrete_sequence=px.colors.sequential.Blues_r)
    fig_pie.update_layout(plot_bgcolor=colors['card_bg'], paper_bgcolor=colors['background'],
                         font_color=colors['text'])
    
    # 3. Карта по регионам (имитация)
    region_data = filtered_df.groupby('region').agg({'revenue': 'sum'}).reset_index()
    fig_map = px.bar(region_data, x='region', y='revenue',
                    title='🌍 Выручка по регионам',
                    color='revenue', color_continuous_scale='Viridis')
    fig_map.update_layout(plot_bgcolor=colors['card_bg'], paper_bgcolor=colors['background'],
                         font_color=colors['text'])
    
    # 4. Маржа прибыли
    profit_data = filtered_df.groupby('category').agg({'profit': 'sum', 'revenue': 'sum'}).reset_index()
    profit_data['margin'] = (profit_data['profit'] / profit_data['revenue'] * 100).round(1)
    fig_margin = px.bar(profit_data, x='category', y='margin',
                       title='💵 Маржа прибыли по категориям (%)',
                       color='margin', color_continuous_scale='RdYlGn')
    fig_margin.update_layout(plot_bgcolor=colors['card_bg'], paper_bgcolor=colors['background'],
                            font_color=colors['text'])
    
    # 5. Сравнение категорий
    comparison_data = filtered_df.groupby(['category', 'region']).agg({'sales': 'sum'}).reset_index()
    fig_comparison = px.sunburst(comparison_data, path=['category', 'region'], values='sales',
                                title='🔍 Детальное сравнение: категории и регионы',
                                color='sales', color_continuous_scale='Blues')
    fig_comparison.update_layout(plot_bgcolor=colors['card_bg'], paper_bgcolor=colors['background'],
                                font_color=colors['text'])
    
    return fig_trend, fig_pie, fig_map, fig_margin, fig_comparison

# Запуск приложения
if __name__ == '__main__':
    print("🚀 Запуск дашборда...")
    print("📊 Откройте в браузере: http://localhost:8050")
    app.run_server(debug=True, host='0.0.0.0', port=8050)
